-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 10.10.2024 klo 06:15
-- Palvelimen versio: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manutd_fans`
--

-- --------------------------------------------------------

--
-- Rakenne taululle `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `news_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` text,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `hidden` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `news_id` (`news_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Vedos taulusta `comments`
--

INSERT INTO `comments` (`id`, `news_id`, `name`, `comment`, `date`, `hidden`) VALUES
(8, 1, 'dogo', 'No morjesta', '2024-09-23 05:53:50', 0),
(10, 5, 'dogo', 'JEE', '2024-09-23 09:05:48', 0),
(9, 1, 'MarkGoldbridge', 'GET IN!', '2024-09-23 05:54:41', 0),
(11, 5, 'dogo', 'JEE', '2024-09-23 09:06:19', 0),
(12, 3, 'dogo', 'Nice', '2024-09-24 06:35:55', 0),
(17, 4, 'dogo', 'BRUNO! BRUNO!', '2024-09-25 07:44:39', 0),
(16, 2, 'dogo', 'Manchester is RED <3', '2024-09-25 07:44:28', 0),
(18, 1, 'Markku', 'Kuka?', '2024-09-30 05:25:21', 0),
(19, 2, 'Markku', 'jes!', '2024-09-30 05:25:27', 0),
(20, 1, 'JoonaGamers', 'Lol paska pelaaja XDDDDD', '2024-10-03 05:40:41', 0);

-- --------------------------------------------------------

--
-- Rakenne taululle `fixtures`
--

DROP TABLE IF EXISTS `fixtures`;
CREATE TABLE IF NOT EXISTS `fixtures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `match_time` time NOT NULL,
  `opponent` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `opponent_logo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Vedos taulusta `fixtures`
--

INSERT INTO `fixtures` (`id`, `date`, `match_time`, `opponent`, `location`, `opponent_logo`) VALUES
(1, '2024-09-15', '15:00:00', 'Liverpool', 'Old Trafford', 'liverpool-logo.png'),
(2, '2024-09-22', '17:30:00', 'Chelsea', 'Stamford Bridge', 'chelsea-logo.png'),
(3, '2024-10-06', '16:00:00', 'Manchester City', 'Etihad Stadium', 'man-city-logo.png'),
(4, '2024-10-20', '14:00:00', 'Arsenal', 'Old Trafford', 'arsenal-logo.png'),
(5, '2024-11-03', '19:00:00', 'Tottenham', 'Tottenham Hotspur Stadium', 'tottenham-logo.png'),
(6, '2024-11-24', '15:00:00', 'Everton', 'Goodison Park', 'everton-logo.png');

-- --------------------------------------------------------

--
-- Rakenne taululle `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `likes` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Vedos taulusta `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `date`, `image`, `likes`) VALUES
(1, 'Manchester United Signs New Striker', 'Manchester United has officially signed a new striker ahead of the upcoming season. The 22-year-old has impressed in his previous club, and fans are excited about the new addition to the team.', '2024-09-10', 'new-striker.jpg', 156),
(2, 'United Wins Derby Against City', 'In a thrilling derby match against Manchester City, Manchester United came from behind to win 3-2 in the final moments of the game. Fans at Old Trafford were ecstatic after the dramatic finish.', '2024-09-08', 'derby-win.jpg', 11),
(3, 'Old Trafford Stadium to Get Major Renovation', 'Manchester United has announced that Old Trafford will undergo significant renovations over the next two years. The improvements will focus on increasing stadium capacity and modernizing the facilities.', '2024-09-05', 'stadium-renovation.jpg', 3),
(4, 'Bruno Fernandes Named Player of the Month', 'Manchester United midfielder Bruno Fernandes has been named the Premier League Player of the Month after his outstanding performances in September, scoring 5 goals and providing 3 assists.', '2024-09-01', 'bruno-fernandes-potm.jpg', 2),
(5, 'Manchester United Youth Team Wins Academy League', 'The Manchester United U18 team won the Academy League after a dominant season. The young Red Devils have shown immense potential, and many are tipped for first-team promotion.', '2024-05-25', 'u18-win.jpg', 2);

-- --------------------------------------------------------

--
-- Rakenne taululle `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `position` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Vedos taulusta `players`
--

INSERT INTO `players` (`id`, `name`, `position`, `country`, `dob`, `image`) VALUES
(16, 'Diogo Dalot', 'Defender', 'Portugal', '1999-03-18', 'dalot.jpg'),
(15, 'Luke Shaw', 'Defender', 'England', '1995-07-12', 'shaw.jpg'),
(14, 'Lisandro Martínez', 'Defender', 'Argentina', '1998-01-18', 'martinez.jpg'),
(13, 'Mason Mount', 'Midfielder', 'England', '1999-01-10', 'mount.jpg'),
(12, 'Christian Eriksen', 'Midfielder', 'Denmark', '1992-02-14', 'eriksen.jpg'),
(10, 'Kobbie Mainoo', 'Midfielder', 'England', '2005-04-19', 'mainoo.jpg'),
(9, 'Manuel Ugarte', 'Midfielder', 'Uruguay', '2001-04-11', 'ugarte.jpg'),
(8, 'Bruno Fernandes', 'Midfielder', 'Portugal', '1994-09-08', 'fernandes.jpg'),
(5, 'Joshua Zirkzee', 'Forward', 'Netherlands', '2001-05-22', 'zirkzee.jpg'),
(6, 'Rasmus Højlund', 'Forward', 'Denmark', '2003-02-04', 'hojlund.jpg'),
(7, 'Ethan Wheatley', 'Forward', 'England', '2006-01-20', 'ethan.jpg'),
(18, 'Victor Lindelöf', 'Defender', 'Sweden', '1994-07-17', 'lindelof.jpg'),
(17, 'Harry Maguire', 'Defender', 'England', '1993-03-05', 'maguire.jpg'),
(1, 'Marcus Rashford', 'Forward', 'England', '1997-10-31', 'rashford.jpg'),
(2, 'Alejandro Garnacho', 'Forward', 'Argentina', '2004-07-01', 'garnacho.jpg'),
(3, 'Amad Diallo', 'Forward', 'Ivory Coast', '2002-07-11', 'amad.jpg'),
(4, 'Antony', 'Forward', 'Brazil', '2000-02-24', 'antony.jpg'),
(11, 'Casemiro', 'Midfielder', 'Brazil', '1992-02-23', 'casemiro.jpg'),
(19, 'Matthijs de Ligt', 'Defender', 'Netherlands', '1999-08-12', 'deligt.jpg'),
(20, 'Leny Yoro', 'Defender', 'France', '2005-11-13', 'yoro.jpg'),
(21, 'Noussair Mazraoui', 'Defender', 'Morocco', '1997-11-14', 'mazraoui.jpg'),
(22, 'Andre Onana', 'Goalkeeper', 'Cameroon', '1996-04-02', 'onana.jpg'),
(23, 'Tom Heaton', 'Goalkeeper', 'England', '1986-04-15', 'heaton.jpg'),
(24, 'Altay Bayindir', 'Goalkeeper', 'Turkey', '1998-04-14', 'bayindir.jpg');

-- --------------------------------------------------------

--
-- Rakenne taululle `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Vedos taulusta `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'dogo', '$2y$10$WVYBs/QGLTatTrKU4ntyiecoc5IU1AbxXCrPjfvJWT01tXFUCLrzC'),
(2, 'MarkGoldbridge', '$2y$10$k78NHZYCiIAEmlMApyDVL.A8Kp8x9RXUW.jEyQT83BWX5nsikbYJG'),
(3, 'Markku', '$2y$10$pa7j2lu/NtAj2zeVyA3HB.FKA2CIjZwQ.Hq7ToF9IFm4me0HA.uWW'),
(4, 'JoonaGamers', '$2y$10$TfSL4E2HllYjyWH9/KH3rubGZ78ua2SLDhA.oYui4EPBGiF786kMu');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
