<?php
// Yhdist� tietokantaan
$servername = "localhost";
$username = "root";
$password = ""; // Jos k�yt�t root-k�ytt�j�� ja et asettanut salasanaa
$dbname = "manutd_fans";

// Luo yhteys
$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys ep�onnistui: " . $conn->connect_error);
}

// Hae pelaajat tietokannasta
$sql = "SELECT name, position, country, dob, image FROM players ORDER BY 
        CASE 
            WHEN position = 'Forward' THEN 1
            WHEN position = 'Midfielder' THEN 2
            WHEN position = 'Defender' THEN 3
            WHEN position = 'Goalkeeper' THEN 4
        END, name ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manchester United Players</title>
    <link rel="stylesheet" href="players.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="manutd_logo.png" alt="Manchester United Logo">
        </div>
        <h1>Meet the Manchester United Players</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="fixtures.php">Fixtures</a></li>
                <li><a href="players.php">Players</a></li> <!-- Linkki players.php-sivulle -->
                <li><a href="news.php">News</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="players">
            <?php
            // Tarkista, l�ytyyk� tuloksia
            if ($result->num_rows > 0) {
                $current_position = "";
                while($row = $result->fetch_assoc()) {
                    // Muuta pelipaikan mukaan
                    if ($current_position != $row["position"]) {
                        if ($current_position != "") {
                            echo '</div>'; // Sulje edellinen pelaajaryhm�
                        }
                        $current_position = $row["position"];
                        echo '<div class="player-category">';
                        echo '<h2>' . htmlspecialchars($current_position) . '</h2>';
                        echo '<div class="player-row">';
                    }

                    echo '<div class="player-card">';
                    echo '<img src="' . htmlspecialchars($row["image"]) . '" alt="' . htmlspecialchars($row["name"]) . '">';
                    echo '<h3>' . htmlspecialchars($row["name"]) . '</h3>';
                    echo '<p>' . htmlspecialchars($row["position"]) . '</p>';
                    echo '<p>' . htmlspecialchars($row["country"]) . '</p>';
                    echo '<p>' . htmlspecialchars($row["dob"]) . '</p>';
                    echo '</div>';
                }
                echo '</div>'; // Sulje viimeinen pelaajaryhm�
                echo '</div>'; // Sulje viimeinen pelipaikka
            } else {
                echo "No players found.";
            }
            ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Manchester United Fans. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
// Sulje yhteys
$conn->close();
?>
