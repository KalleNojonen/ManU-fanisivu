<?php
session_start();

// Yhdist� tietokantaan
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "manutd_fans";

// Luo yhteys
$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys ep�onnistui: " . $conn->connect_error);
}

// Tarkista, onko k�ytt�j� admin
$isAdmin = isset($_SESSION['username']) && $_SESSION['username'] === 'dogo';

// K�sittele kommentin piilottaminen ja palauttaminen
if ($_SERVER['REQUEST_METHOD'] == 'POST' && (isset($_POST['hide_comment']) || isset($_POST['show_comment']))) {
    $comment_id = $_POST['comment_id'];
    $hidden_status = isset($_POST['hide_comment']) ? 1 : 0; // 1 = piilota, 0 = n�yt�
    if ($isAdmin) {
        $stmt = $conn->prepare("UPDATE comments SET hidden = ? WHERE id = ?");
        $stmt->bind_param("ii", $hidden_status, $comment_id);
        $stmt->execute();
        $stmt->close();
    }
}

// Hae uutiset tietokannasta
$sql = "SELECT id, title, content, date, image, likes FROM news ORDER BY date DESC";
$result = $conn->query($sql);

// K�sittele kommentin lis��minen
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_comment'])) {
    $news_id = $_POST['news_id'];
    $comment = $_POST['comment'];
    
    $name = isset($_SESSION['username']) ? $_SESSION['username'] : "Anonymous"; 

    if (!empty($comment)) {
        $stmt = $conn->prepare("INSERT INTO comments (news_id, name, comment) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $news_id, $name, $comment);
        $stmt->execute();
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manchester United News</title>
    <link rel="stylesheet" href="news.css">
    <script>
        // Funktio linkin kopioimiseen
        function copyLink(newsId) {
            var tempInput = document.createElement("input");
            document.body.appendChild(tempInput);
            
            // Luo uutislinkki
            var url = window.location.origin + '/news.php?id=' + newsId;
            tempInput.value = url;

            tempInput.select();
            tempInput.setSelectionRange(0, 99999); // For mobile devices
            document.execCommand("copy");

            document.body.removeChild(tempInput);

            alert("Linkki kopioitu: " + url);
        }
    </script>
</head>
<body>
    <header>
        <div class="logo">
            <img src="manutd_logo.png" alt="Manchester United Logo">
        </div>
        <h1>Manchester United News</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="fixtures.php">Fixtures</a></li>
                <li><a href="players.php">Players</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="news">
            <h2>Latest News</h2>

            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $news_id = $row["id"];
                    echo '<div class="news-card">';
                    
                    // "Jaa"-painike (kopioi linkin)
                    echo '<button class="share-btn" onclick="copyLink(' . $news_id . ')">Jaa</button>';
                    
                    if ($row["image"]) {
                        echo '<img src="' . htmlspecialchars($row["image"]) . '" alt="' . htmlspecialchars($row["title"]) . '">';
                    }
                    echo '<h3>' . htmlspecialchars($row["title"]) . '</h3>';
                    echo '<p><strong>Date:</strong> ' . date("d M Y", strtotime($row["date"])) . '</p>';
                    echo '<p>' . nl2br(htmlspecialchars($row["content"])) . '</p>';

                    // Kommentit ja adminin piilotoiminto
                    $comment_sql = "SELECT id, name, comment, date, hidden FROM comments WHERE news_id = $news_id ORDER BY date DESC";
                    $comments_result = $conn->query($comment_sql);
                    if ($comments_result->num_rows > 0) {
                        echo '<div class="comments-section">';
                        echo '<h4>Comments</h4>';
                        while ($comment_row = $comments_result->fetch_assoc()) {
                            echo '<div class="comment">';
                            if ($comment_row['hidden'] == 0 || $isAdmin) {
                                echo '<p><strong>' . htmlspecialchars($comment_row['name']) . ':</strong> ' . htmlspecialchars($comment_row['comment']) . '</p>';
                                echo '<p class="comment-date">' . date("d M Y, H:i", strtotime($comment_row['date'])) . '</p>';
                            }
                            
                            // Adminin piilotus/n�ytt�toiminto
                            if ($isAdmin) {
                                if ($comment_row['hidden'] == 0) {
                                    // Piilota kommentti -nappi
                                    echo '
                                    <form action="news.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="comment_id" value="' . $comment_row["id"] . '">
                                        <button type="submit" name="hide_comment">Piilota kommentti</button>
                                    </form>';
                                } else {
                                    // N�yt� kommentti -nappi
                                    echo '
                                    <form action="news.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="comment_id" value="' . $comment_row["id"] . '">
                                        <button type="submit" name="show_comment">Nayta kommentti</button>
                                    </form>';
                                }
                            }
                            echo '</div>';
                        }
                        echo '</div>';
                    } else {
                        echo '<p>No comments yet. Be the first to comment!</p>';
                    }

                    // Kommentointilomake
                    echo '
                    <div class="comment-form">
                        <h4>Leave a Comment</h4>';
                    
                    if (isset($_SESSION['username'])) {
                        echo '<p>Commenting as: <strong>' . htmlspecialchars($_SESSION['username']) . '</strong></p>';
                    } else {
                        echo '<p>You are commenting as <strong>Anonymous</strong></p>';
                    }

                    echo '
                        <form action="news.php" method="POST">
                            <input type="hidden" name="news_id" value="' . $news_id . '">
                            <textarea name="comment" placeholder="Your Comment" required></textarea>
                            <button type="submit" name="submit_comment">Post Comment</button>
                        </form>
                    </div>';
                    echo '</div>';
                }
            } else {
                echo '<p>No news available at the moment.</p>';
            }
            ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Manchester United Fans. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
