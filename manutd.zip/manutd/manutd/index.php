<?php
// Yhdist� tietokantaan (voit poistaa t�m�n, jos et hae tietoja tietokannasta etusivulla)
$servername = "localhost";
$username = "root";
$password = ""; // Jos k�yt�t root-k�ytt�j�� ja et asettanut salasanaa
$dbname = "manutd_fans";

// Luo yhteys tietokantaan (voit poistaa t�m�n osan, jos et hae tietoja index.php-sivulla)
$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys ep�onnistui: " . $conn->connect_error);
}

// Voit lis�t� tietokantakyselyj� t�h�n, jos tarvitset tietoa etusivulle
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manchester United Fan Page</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="manutd_logo.png" alt="Manchester United Logo">
        </div>
        <h1>Welcome to the Manchester United Fan Page!</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="fixtures.php">Fixtures</a></li>
                <li><a href="players.php">Players</a></li> <!-- Linkki players.php-sivulle -->
                <li><a href="news.php">News</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <!-- Lis�� bannerikuva -->
    <div class="banner">
        <img src="your-banner-image.jpg" alt="Manchester United Banner">
    </div>

    <main>
        <section>
            <h2>Welcome to the Manchester United Fan Page!</h2>
            <p>This is the ultimate fan page for Manchester United supporters. Here, you can check the upcoming fixtures, meet our amazing players, and stay updated with the latest news!</p>
        </section>

        <!-- Pelaajien esittelyn sijaan lis�t��n linkki players.php-sivulle -->
        <section class="players-intro">
            <h2>Meet Our Players</h2>
            <p>Get to know the players that make Manchester United one of the best football clubs in the world.</p>
            <a href="players.php" class="button">Check out our players</a> <!-- Linkki players.php-sivulle -->
        </section>

        <!-- Linkki otteluohjelmaan -->
        <section class="fixtures-intro">
            <h2>Upcoming Matches</h2>
            <p>Stay up to date with all the upcoming Manchester United fixtures.</p>
            <a href="fixtures.php" class="button">View Fixtures</a>
        </section>

        <!-- Voit lis�t� my�s uutisia tai muuta tietoa -->
        <section class="news-intro">
    <h2>Latest News</h2>
    <p>Check out the latest news and updates from Manchester United.</p>
    <a href="news.php" class="button">Read News</a> <!-- Linkki news.php-sivulle -->
</section>
<section class="next-match">
    <h2>Next Match</h2>
    <?php
    $match_sql = "SELECT opponent, date, match_time, location FROM fixtures WHERE date >= CURDATE() ORDER BY date ASC LIMIT 1";
    $match_result = $conn->query($match_sql);

    if ($match_result->num_rows > 0) {
        $match_row = $match_result->fetch_assoc();
        echo '<div class="match-details">';
        echo '<p><strong>Opponent:</strong> ' . htmlspecialchars($match_row["opponent"]) . '</p>';
        echo '<p><strong>Date:</strong> ' . date("d M Y", strtotime($match_row["date"])) . '</p>';
        echo '<p><strong>Time:</strong> ' . htmlspecialchars($match_row["match_time"]) . '</p>';
        echo '<p><strong>Location:</strong> ' . htmlspecialchars($match_row["location"]) . '</p>';
        echo '</div>';
    } else {
        echo '<p>No upcoming matches found.</p>';
    }
    ?>
</section>
<section class="team-info">
    <h2>About Manchester United</h2>
    <p>Manchester United is one of the most successful football clubs in the world, with a rich history and numerous trophies. From the "Busby Babes" to Sir Alex Ferguson's era of dominance, Manchester United has captured the hearts of millions.</p>
</section>
<section class="events-calendar">
    <h2>Upcoming Events</h2>
    <ul>
        <li><strong>Fan Meet & Greet:</strong> 15th October 2024</li>
        <li><strong>Training Camp:</strong> 1st November 2024</li>
        <li><strong>Christmas Party:</strong> 24th December 2024</li>
    </ul>
</section>



    </main>

    <footer>
        <p>&copy; 2024 Manchester United Fans. All rights reserved.</p>
    </footer>
</body>
</html>

<?php
// Sulje tietokantayhteys, jos k�yt�t tietokantaa etusivulla
$conn->close();
?>
