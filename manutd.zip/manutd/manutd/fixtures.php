<?php
// Yhdistä tietokantaan
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "manutd_fans";

// Luo yhteys
$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkista yhteys
if ($conn->connect_error) {
    die("Yhteys epäonnistui: " . $conn->connect_error);
}

// Hae tulevat ottelut tietokannasta
$sql = "SELECT * FROM fixtures ORDER BY date ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fixtures</title>
    <link rel="stylesheet" href="styles.css"> <!-- Tämä on pää CSS-tiedosto -->
    <link rel="stylesheet" href="fixtures.css"> <!-- Tämä on Fixtures-sivun erityinen CSS-tiedosto -->
    <style>
        body {
            background-color: #000; /* Musta tausta koko sivulle */
            color: #fff; /* Valkoinen teksti mustalla taustalla */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #1b1b1b; /* Tumma sävy */
            color: white;
            padding: 10px 0;
            text-align: center;
            position: relative;
            margin-bottom: 0; /* Poista väli bannerin ja headerin väliltä */
        }

        header .logo {
            position: absolute;
            top: 10px;
            left: 10px;
        }

        header .logo img {
            width: 75px; /* Aseta haluamasi leveys */
            height: auto;
        }

        h1 {
            margin-top: 0;
        }

        .fixtures {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 20px;
        }

        .fixture-card {
            background-color: #000; /* Musta taustaväri kortille */
            border: 1px solid #333; /* Tummanharmaa reunus */
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3); /* Tummempi varjo mustalla taustalla */
            color: #fff; /* Valkoinen teksti mustalla taustalla */
        }

        .opponent-logo {
            width: 100px; /* Säädä kuvaa halutulle leveydelle */
            height: auto;
            margin-bottom: 10px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="manutd_logo.png" alt="Manchester United Logo"> <!-- Vaihda tähän oikea logo-tiedosto -->
        </div>
        <h1>Manchester United Fixtures</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="fixtures.php">Fixtures</a></li>
                <li><a href="players.php">Players</a></li> <!-- Linkki players.php-sivulle -->
                <li><a href="news.php">News</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Upcoming Matches</h2>
        <section class="fixtures">
            <?php
            // Tarkista, löytyykö tuloksia
            if ($result->num_rows > 0) {
                // Tulosta jokainen ottelu korttina
                while($row = $result->fetch_assoc()) {
                    echo '<div class="fixture-card">';
                    echo '<img src="' . htmlspecialchars($row["opponent_logo"]) . '" alt="Opponent Logo" class="opponent-logo">';
                    echo '<h3>' . htmlspecialchars($row["opponent"]) . '</h3>';
                    echo '<p>Date: ' . date("d M Y", strtotime($row["date"])) . '</p>';
                    echo '<p>Time: ' . htmlspecialchars($row["match_time"]) . '</p>';
                    echo '<p>Location: ' . htmlspecialchars($row["location"]) . '</p>';
                    echo '</div>';
                }
            } else {
                echo '<p>No fixtures found.</p>';
            }
            ?>
        </section>
    </main>
</body>
</html>

<?php
// Sulje yhteys
$conn->close();
?>
