<?php
session_start();

// Yhdistetään tietokantaan
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "manutd_fans";

$conn = new mysqli($servername, $username, $password, $dbname);

// Tarkistetaan yhteys
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Virheilmoitukset
$login_error = '';
$register_error = '';

// Kirjautumislomakkeen käsittely
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Valmistellaan SQL-kysely käyttäjän tarkistamiseksi
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jos käyttäjä löytyy
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Tarkistetaan salasana
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            header("Location: index.php"); // Ohjataan etusivulle
            exit();
        } else {
            $login_error = "Invalid username or password!";
        }
    } else {
        $login_error = "Invalid username or password!";
    }
    $stmt->close();
}

// Rekisteröintilomakkeen käsittely
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Tarkistetaan, että salasanat täsmäävät
    if ($new_password != $confirm_password) {
        $register_error = "Passwords do not match!";
    } else {
        // Tarkistetaan, onko käyttäjänimi jo olemassa
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $new_username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $register_error = "Username is already taken!";
        } else {
            // Hashataan salasana ja lisätään uusi käyttäjä tietokantaan
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $new_username, $hashed_password);

            if ($stmt->execute()) {
                $_SESSION['username'] = $new_username;
                header("Location: index.php"); // Ohjataan etusivulle
                exit();
            } else {
                $register_error = "Error in registration!";
            }
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login & Register</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="login-container">
        <h2>Login to Manchester United Fans</h2>

        <!-- Näytetään kirjautumisen virheilmoitus, jos sellainen on -->
        <?php if (!empty($login_error)): ?>
            <p class="login-error"><?php echo $login_error; ?></p>
        <?php endif; ?>

        <!-- Kirjautumislomake -->
        <form action="login.php" method="post" class="login-form">
            <input type="hidden" name="login" value="1">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>

        <hr>

        <h2>Register a New Account</h2>

        <!-- Näytetään rekisteröinnin virheilmoitus, jos sellainen on -->
        <?php if (!empty($register_error)): ?>
            <p class="login-error"><?php echo $register_error; ?></p>
        <?php endif; ?>

        <!-- Rekisteröintilomake -->
        <form action="login.php" method="post" class="register-form">
            <input type="hidden" name="register" value="1">
            <label for="new_username">Username:</label>
            <input type="text" id="new_username" name="new_username" required>

            <label for="new_password">Password:</label>
            <input type="password" id="new_password" name="new_password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>
