﻿
namespace Hirsipuu2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnArvaa = new System.Windows.Forms.Button();
            this.lblArvattavaSana = new System.Windows.Forms.Label();
            this.txtKirjain = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblelamia = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonArvaa = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnArvaa
            // 
            this.btnArvaa.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.btnArvaa.Location = new System.Drawing.Point(218, 62);
            this.btnArvaa.Name = "btnArvaa";
            this.btnArvaa.Size = new System.Drawing.Size(302, 100);
            this.btnArvaa.TabIndex = 0;
            this.btnArvaa.Text = "Arvaa kirjain";
            this.btnArvaa.UseVisualStyleBackColor = true;
            this.btnArvaa.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblArvattavaSana
            // 
            this.lblArvattavaSana.AutoSize = true;
            this.lblArvattavaSana.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.lblArvattavaSana.Location = new System.Drawing.Point(30, 3);
            this.lblArvattavaSana.Name = "lblArvattavaSana";
            this.lblArvattavaSana.Size = new System.Drawing.Size(463, 55);
            this.lblArvattavaSana.TabIndex = 1;
            this.lblArvattavaSana.Text = "arvattavaSanaLabeli";
            // 
            // txtKirjain
            // 
            this.txtKirjain.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.txtKirjain.Location = new System.Drawing.Point(14, 61);
            this.txtKirjain.MaximumSize = new System.Drawing.Size(100, 100);
            this.txtKirjain.MinimumSize = new System.Drawing.Size(100, 100);
            this.txtKirjain.Name = "txtKirjain";
            this.txtKirjain.Size = new System.Drawing.Size(100, 100);
            this.txtKirjain.TabIndex = 2;
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 55;
            this.listBox1.Location = new System.Drawing.Point(1002, 177);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(269, 334);
            this.listBox1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.label1.Location = new System.Drawing.Point(368, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(327, 55);
            this.label1.TabIndex = 4;
            this.label1.Text = "Elämiä jäljellä:";
            // 
            // lblelamia
            // 
            this.lblelamia.AutoSize = true;
            this.lblelamia.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.lblelamia.Location = new System.Drawing.Point(727, 244);
            this.lblelamia.Name = "lblelamia";
            this.lblelamia.Size = new System.Drawing.Size(51, 55);
            this.lblelamia.TabIndex = 5;
            this.lblelamia.Text = "0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(536, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "VAIKEA";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(626, 129);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "HELPPO";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.label2.Location = new System.Drawing.Point(216, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 55);
            this.label2.TabIndex = 8;
            this.label2.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.label3.Location = new System.Drawing.Point(12, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 55);
            this.label3.TabIndex = 9;
            this.label3.Text = "Pisteet:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.textBox1.Location = new System.Drawing.Point(14, 174);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(399, 62);
            this.textBox1.TabIndex = 10;
            // 
            // buttonArvaa
            // 
            this.buttonArvaa.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.buttonArvaa.Location = new System.Drawing.Point(476, 163);
            this.buttonArvaa.Name = "buttonArvaa";
            this.buttonArvaa.Size = new System.Drawing.Size(302, 73);
            this.buttonArvaa.TabIndex = 11;
            this.buttonArvaa.Text = "Arvaa sana";
            this.buttonArvaa.UseVisualStyleBackColor = true;
            this.buttonArvaa.Click += new System.EventHandler(this.buttonArvaa_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(30, 314);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(803, 345);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(920, 546);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(351, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Vaikeustaso on tehty vähän erilailla joten ei toimi täysin miten pitäisi ehkä.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1405, 693);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonArvaa);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblelamia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtKirjain);
            this.Controls.Add(this.lblArvattavaSana);
            this.Controls.Add(this.btnArvaa);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnArvaa;
        private System.Windows.Forms.Label lblArvattavaSana;
        private System.Windows.Forms.TextBox txtKirjain;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblelamia;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonArvaa;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
    }
}

