﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hirsipuu2
{
    public partial class Form1 : Form
    {
        string[] arvattavatSanat = { "hirsipuu", "koodi", "keinu", "peili", "ohjelmointikieli", "bussilakko", "visualstudio", "suihkuturbiiniapumekaanikko"};
        Random satunnaisGeneraattori = new Random();
        string arvottuSana;
        int elamiaJaljellaNum = 5;
        public Form1()
        {
            InitializeComponent();

            AloitaPeli();
        }

        private void AloitaPeli()
        {
            
            listBox1.Items.Clear();
            elamiaJaljellaNum = 5;

            if (System.IO.File.Exists("juu.csv") == true)
            {
                arvattavatSanat = System.IO.File.ReadAllLines("juu.csv");
            }

            Array.Sort(arvattavatSanat);

            int satunnaisLuku = satunnaisGeneraattori.Next(0, arvattavatSanat.Length);
            arvottuSana = arvattavatSanat[satunnaisLuku];
            arvottuSana = arvottuSana.ToLower();
            lblArvattavaSana.Text = "";
            for(int i=0;i< arvottuSana.Length;i++)
            {
                lblArvattavaSana.Text += "_ ";
            }
            lblelamia.Text = elamiaJaljellaNum.ToString();
            label2.Text = "0";

            


        }

        private void LopetaPeli(string paattymisteksti)
        {
            pictureBox1.Invalidate();
            DialogResult result = MessageBox.Show(paattymisteksti, "", (MessageBoxButtons.YesNo));
            if (result == DialogResult.Yes)
            {
                AloitaPeli();

            }
            else
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string kirjain = txtKirjain.Text;
            kirjain = kirjain.ToLower();
            if(kirjain.Length <= 0)
            {
                MessageBox.Show("Eipä ollut kirjaimia");
            }
            else
            {
                string labelinSana = "";
                
                if (listBox1.Items.IndexOf(kirjain) == -1)
                {
                    listBox1.Items.Add(kirjain);
                    bool loytyiko = false;

                    for (int i = 0; i < arvottuSana.Length; i++)
                    {
                        if (arvottuSana[i] == kirjain[0])
                        {
                            labelinSana += arvottuSana[i];
                            loytyiko = true;
                        }
                        else
                        {
                            labelinSana += lblArvattavaSana.Text[i];
                        }

                    }
                    if (labelinSana.Contains('_') == false)
                    {
                        LopetaPeli("Arvasit sanan oikein! Haluatko yrittää uudelleen?");
                        int value1 = 0;
                        value1++;
                        label2.Text = value1.ToString();
                    }
                    else
                    {

                        lblArvattavaSana.Text = labelinSana;
                        if (loytyiko == false)
                        {
                            elamiaJaljellaNum--;
                        }
                        if (elamiaJaljellaNum <= 0)
                        {
                            int value2 = 0;
                            value2--;
                            label2.Text = value2.ToString();
                            LopetaPeli("Hävisit pelin. Haluatko yrittää uudelleen?");
                        }
                    }
                    pictureBox1.Invalidate();
                    lblelamia.Text = elamiaJaljellaNum.ToString();
                }
                else
                {
                    MessageBox.Show("Kirjain oli jo arvattu");
                }
   
            }
            txtKirjain.Text = "";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            AloitaPeli();
            int satunnaisLuku = satunnaisGeneraattori.Next(5, 8);
            arvottuSana = arvattavatSanat[satunnaisLuku];
            elamiaJaljellaNum = 3;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AloitaPeli();
            int satunnaisLuku = satunnaisGeneraattori.Next(0, 4);
            arvottuSana = arvattavatSanat[satunnaisLuku];
            elamiaJaljellaNum = 9;
            lblelamia.Text = elamiaJaljellaNum.ToString();
        }

        private void buttonArvaa_Click(object sender, EventArgs e)
        {
            string arvaus = textBox1.Text;
            arvaus = arvaus.ToLower();
            if (arvaus.CompareTo(arvottuSana) == 0)
            {
                LopetaPeli("Arvasit sanan oikein. Haluatko yrittää uudelleen?");
                int value1 = 0;
                value1++;
                label2.Text = value1.ToString();
            }
            else
            {
                elamiaJaljellaNum--;
                lblelamia.Text = elamiaJaljellaNum.ToString();
                if(elamiaJaljellaNum <= 0)
                {
                    LopetaPeli("Hävisit pelin. Haluatko yrittää uudelleen?");
                    int value1 = 0;
                    value1--;
                    label2.Text = value1.ToString();
                }
            }
            // Pyytää suorittamaan piirto/paint tapahtumat uudelleen
            pictureBox1.Invalidate();
        }
        

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            

            int keskipisteX = pictureBox1.Width / 2;
            int keskipisteY = pictureBox1.Height / 2;
            keskipisteY += 100;

            if(elamiaJaljellaNum < 5)
            {
                // piirrä ukon vartalo
                e.Graphics.DrawLine(new Pen(Brushes.Blue), new Point(keskipisteX, 100), new Point(keskipisteX, keskipisteY));
            }

            if(elamiaJaljellaNum < 4)
            {
                //piirrä ukon vasen käsi
                e.Graphics.DrawLine(new Pen(Brushes.Navy), new Point(keskipisteX, 105), new Point(keskipisteX - 50, 155));
                //piirrä ukon oikea käsi
                e.Graphics.DrawLine(new Pen(Brushes.Navy), new Point(keskipisteX, 105), new Point(keskipisteX + 50, 155));
            }

            if(elamiaJaljellaNum < 3)
            {
                // piirrä ukon vasen jalka
                e.Graphics.DrawLine(new Pen(Brushes.Green), new Point(keskipisteX, keskipisteY), new Point(keskipisteX - 50, keskipisteY + 50));
            }

            if(elamiaJaljellaNum < 2)
            {
                // piirrä ukon oikea jalka
                e.Graphics.DrawLine(new Pen(Brushes.Green), new Point(keskipisteX, keskipisteY), new Point(keskipisteX + 50, keskipisteY + 50));
            }

            if(elamiaJaljellaNum < 1)
            {
                // piirrä ukon pää
                e.Graphics.DrawEllipse(new Pen(Brushes.Coral), keskipisteX - 100, 5, 200, 100);
            }
                                                      
        }
    }
}